$(function(){
	$('#currentGuess').val('');
    $('#currentGuess').prop('disabled',false);
	$('#currentGuess').focus();
	function capitalizeFirstLetter(string) {
		return string.charAt(0).toUpperCase() + string.slice(1);
	}
	function dumbDownName(name){
		return name.toLowerCase().replace(" ",'').replace("'","");
	}
	$('#skip').click(function(){
		pickNewChampion();
		$('#currentGuess').focus();
		
	})
	window.timerId=-1;
	$.get("champion.json",function(data){
		window.champs=data['data'];
		window.champions=[];
		count=0;
		for(ch in window.champs){
			window.champions[count++]=ch;
		}
		pickNewChampion();
	});
	
	function pickNewChampion(){
		championChosen=Math.floor(Math.random()*_.size(window.champions));
		window.currentChampion=window.champs[window.champions[championChosen]]; //black magics
		$('#champion-title').html(capitalizeFirstLetter(window.currentChampion['title']));
		$('#currentGuess').val('');
	}
$('#currentGuess').on('keyup',function(){
	if(window.timerId==-1){
		 window.timerId=setInterval(function(){
			 $('#timer').html(parseInt($('#timer').html())-1);
			 if($('#timer').html()==0){
				 clearInterval(window.timerId);
				 $('#currentGuess').prop('disabled',true);
			 }
	},1000);
	}
		 if(dumbDownName($('#currentGuess').val())==dumbDownName(window.currentChampion['name'])){
			 pickNewChampion();
			 
			 $('#currentGuesses').html(parseInt($('#currentGuesses').html())+1);
			 
		 }
		 console.log($('#currentGuess').val()+"=="+dumbDownName(window.currentChampion['name']));
	
	
});
});